Product: Sixteen Drawers, September 2014

Designer: Simon Kirkby

Support:  

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
Sixteen Drawers is designed to be printed on a laser cutter.  They can be made from plywood or acrylic.